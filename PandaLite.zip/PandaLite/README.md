# PandaLite

A minimal Panda-style Android AI agent. You give a voice or text command, Gemini looks at the
screen (via an Accessibility Service) and taps, types and scrolls until the task is done.

## Run it
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Run on a real phone (Android 8.0+).
3. Get a Gemini API key at https://aistudio.google.com/apikey, paste it into the app, tap Save.
4. Tap "Enable accessibility", choose PandaLite and turn it on.
5. Type or speak a command, e.g. "Open Chrome and search for weather in London".

## Notes
- The model name is editable in the app. If a name stops working, use a current one from AI Studio.
- The API key is stored in app-private SharedPreferences (plain). Use EncryptedSharedPreferences for anything serious.
- Each step sends the visible screen text (password fields are hidden) to Gemini.
- It stops after 20 steps, and the Stop button cancels at any time.
- Some apps (banking, DRM video) block accessibility reading, so the agent can't see them.

## Structure
- `AgentService.kt`: accessibility service that reads the screen and performs actions
- `GeminiClient.kt`: REST call to the Gemini API
- `AgentLoop.kt`: screen -> Gemini -> action loop and the system prompt
- `MainActivity.kt`: UI, key storage, voice input
