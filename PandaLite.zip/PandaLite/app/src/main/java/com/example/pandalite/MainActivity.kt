package com.example.pandalite

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val agent = AgentLoop { msg -> runOnUiThread { appendLog(msg) } }

    private lateinit var apiKey: EditText
    private lateinit var model: EditText
    private lateinit var command: EditText
    private lateinit var logView: TextView

    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) {
            command.setText(text)
            runAgent()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        apiKey = findViewById(R.id.apiKey)
        model = findViewById(R.id.model)
        command = findViewById(R.id.command)
        logView = findViewById(R.id.log)

        val prefs = getSharedPreferences("panda", MODE_PRIVATE)
        apiKey.setText(prefs.getString("key", ""))
        model.setText(prefs.getString("model", "gemini-2.5-flash"))

        findViewById<Button>(R.id.saveBtn).setOnClickListener {
            prefs.edit()
                .putString("key", apiKey.text.toString().trim())
                .putString("model", model.text.toString().trim())
                .apply()
            toast("Saved")
        }
        findViewById<Button>(R.id.enableBtn).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.micBtn).setOnClickListener {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "What should Panda do?")
            }
            try { speech.launch(i) } catch (e: Exception) { toast("Speech recognition not available") }
        }
        findViewById<Button>(R.id.runBtn).setOnClickListener { runAgent() }
        findViewById<Button>(R.id.stopBtn).setOnClickListener { agent.running = false }
    }

    private fun runAgent() {
        val key = apiKey.text.toString().trim()
        val goal = command.text.toString().trim()
        if (key.isBlank()) { toast("Enter your Gemini API key"); return }
        if (goal.isBlank()) { toast("Enter or speak a command"); return }
        if (AgentService.instance == null) {
            toast("Turn on PandaLite in Accessibility settings")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if (agent.running) { toast("Already running"); return }
        logView.text = "Goal: $goal"
        val m = model.text.toString().trim().ifBlank { "gemini-2.5-flash" }
        scope.launch { agent.run(goal, key, m) }
    }

    private fun appendLog(msg: String) { logView.append("\n$msg") }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
