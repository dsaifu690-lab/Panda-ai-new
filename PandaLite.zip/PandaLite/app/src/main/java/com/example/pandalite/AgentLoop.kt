package com.example.pandalite

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** The "brain": screen -> Gemini -> action -> repeat until done. */
class AgentLoop(private val log: (String) -> Unit) {

    @Volatile var running = false

    companion object {
        private const val MAX_STEPS = 20

        private const val SYSTEM = """
You control an Android phone on the user's behalf. Each turn you get the GOAL, your PREVIOUS ACTIONS,
and the CURRENT SCREEN as a numbered list of elements. Choose ONE next action.
Reply with JSON only, in exactly this shape:
{"thought":"short reasoning","action":"<name>", ...args}

Actions:
- {"action":"open_app","name":"Chrome"}
- {"action":"click","index":3}
- {"action":"type","index":5,"text":"hello"}
- {"action":"scroll","direction":"down"}   (or "up")
- {"action":"back"}
- {"action":"home"}
- {"action":"wait"}
- {"action":"ask","message":"question for the user"}   (stops and asks the user)
- {"action":"done","message":"what was accomplished"}

Rules:
- Use element numbers from the CURRENT SCREEN only. Numbers change every turn.
- Never type passwords, card numbers or one-time codes.
- Before sending a message/email, making a purchase, deleting data or posting publicly,
  use "ask" to get the user's confirmation unless the GOAL explicitly told you to do it.
- If something fails twice, try a different approach or use "ask".
- When the goal is complete, use "done".
"""
    }

    suspend fun run(goal: String, apiKey: String, model: String) = withContext(Dispatchers.IO) {
        running = true
        try {
            val first = AgentService.instance
            if (first == null) { log("⚠️ Enable the accessibility service first."); return@withContext }

            first.home()
            delay(900)
            val history = mutableListOf<String>()

            for (step in 1..MAX_STEPS) {
                if (!running) { log("⏹ Stopped."); return@withContext }
                val service = AgentService.instance
                if (service == null) { log("⚠️ Accessibility service lost."); return@withContext }

                val screen = service.snapshot()
                val prompt = "GOAL: $goal\n\nPREVIOUS ACTIONS:\n" +
                    history.takeLast(8).joinToString("\n").ifBlank { "(none)" } +
                    "\n\nCURRENT SCREEN:\n$screen"

                val reply = try {
                    GeminiClient.generate(apiKey, model, SYSTEM, prompt)
                } catch (e: Exception) { log("❌ ${e.message}"); return@withContext }

                val json = try {
                    JSONObject(reply.trim().removePrefix("```json").removeSuffix("```").trim())
                } catch (e: Exception) { log("❌ Bad reply from model: ${reply.take(120)}"); return@withContext }

                val action = json.optString("action")
                log("$step. ${json.optString("thought")} → $action")

                val ok = when (action) {
                    "open_app" -> service.openApp(json.optString("name"))
                    "click" -> service.click(json.optInt("index", -1))
                    "type" -> service.type(json.optInt("index", -1), json.optString("text"))
                    "scroll" -> service.scroll(json.optString("direction", "down"))
                    "back" -> service.back()
                    "home" -> service.home()
                    "wait" -> true
                    "ask" -> { log("❓ ${json.optString("message")}"); return@withContext }
                    "done" -> { log("✅ ${json.optString("message")}"); return@withContext }
                    else -> { log("❌ Unknown action: $action"); return@withContext }
                }
                history.add("$step. ${json.toString().take(140)} -> ${if (ok) "ok" else "FAILED"}")
                delay(1300)
            }
            log("⏱ Reached the $MAX_STEPS-step limit.")
        } finally {
            running = false
        }
    }
}
