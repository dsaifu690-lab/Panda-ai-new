package com.example.pandalite

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** The agent eyes and hands: reads the screen and performs taps, typing, scrolling. */
class AgentService : AccessibilityService() {

    companion object {
        @Volatile var instance: AgentService? = null
        private const val MAX_NODES = 150
    }

    private var nodes: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Returns a numbered text description of the screen. Password fields are hidden. */
    fun snapshot(): String {
        val root = rootInActiveWindow ?: return "(screen unavailable)"
        val list = mutableListOf<AccessibilityNodeInfo>()
        val sb = StringBuilder("App: ${root.packageName}\n")

        fun walk(n: AccessibilityNodeInfo) {
            if (list.size >= MAX_NODES) return
            if (n.isVisibleToUser) {
                val raw = (n.text ?: n.contentDescription)?.toString()
                val label = if (n.isPassword) "(hidden)" else raw?.replace("\n", " ")?.take(80)
                val interactive = n.isClickable || n.isEditable || n.isScrollable || n.isCheckable
                if (interactive || !label.isNullOrBlank()) {
                    val flags = buildList {
                        if (n.isClickable) add("click")
                        if (n.isEditable) add("edit")
                        if (n.isScrollable) add("scroll")
                        if (n.isChecked) add("checked")
                    }
                    val type = n.className?.toString()?.substringAfterLast('.') ?: "View"
                    sb.append("[${list.size}] $type \"${label ?: ""}\" $flags\n")
                    list.add(n)
                }
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        nodes = list
        return sb.toString()
    }

    fun click(index: Int): Boolean {
        val node = nodes.getOrNull(index) ?: return false
        var cur: AccessibilityNodeInfo? = node
        while (cur != null) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        tapAt(r.exactCenterX(), r.exactCenterY())
        return true
    }

    fun type(index: Int, text: String): Boolean {
        val node = nodes.getOrNull(index) ?: return false
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scroll(direction: String): Boolean {
        val node = nodes.firstOrNull { it.isScrollable } ?: return false
        val action = if (direction == "up") AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                     else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        return node.performAction(action)
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)

    fun openApp(name: String): Boolean {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
            ?: return false
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return true
    }

    private fun tapAt(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build()
        dispatchGesture(gesture, null, null)
    }
}
